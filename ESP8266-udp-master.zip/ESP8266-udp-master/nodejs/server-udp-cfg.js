/*
    UDP Server Configuration
*/
module.exports = {
    // will listen on all interfaces
    host : '0.0.0.0',
    port : 48000
};

