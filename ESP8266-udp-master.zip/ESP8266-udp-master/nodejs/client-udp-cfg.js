/*
    UDP Client Configuration
*/
module.exports = {
    // edit the address to match the IP address of 
    // the machine where the server will run on.
    host : '192.168.0.7',
    port : 48000,
    repeat: 5
};

