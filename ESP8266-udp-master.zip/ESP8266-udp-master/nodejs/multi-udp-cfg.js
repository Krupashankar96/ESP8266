/*
    UDP Multi-Cast Client Configuration
*/
module.exports = {
    // use this address for muli-cast
    addr : '224.0.0.1',
    port : 54000,
};

