load('api_aws.js');
load('api_azure.js');
load('api_config.js');
load('api_dash.js');
load('api_events.js');
load('api_gcp.js');
load('api_gpio.js');
load('api_mqtt.js');
load('api_shadow.js');
load('api_timer.js');
load('api_sys.js');
load('api_watson.js');
load('api_net.js');
load('api_uart.js');

let is_wifi_connect = false;
let outTopic = Cfg.get('device.id')+'/Odemo';
let inTopic = Cfg.get('device.id')+'/Idemo';
let counter = 10;
let hudi_val = 30;
let uartNo = 0;   // Uart number used for this example
let rxAcc = '';   // Accumulated Rx data, will be echoed back to Tx
let value = false;
let btn = Cfg.get('board.btn1.pin');              // Built-in button GPIO
let led = Cfg.get('board.led1.pin');              // Built-in LED GPIO number
let onhi = Cfg.get('board.led1.active_high');     // LED on when high?
let state = {on: false, btnCount: 0, uptime: 0};  // Device state
let online = false;                               // Connected to the cloud?

let setLED = function(on) {
  let level = onhi ? on : !on;
  GPIO.write(led, level);
  print('LED on ->', on);
};

GPIO.set_mode(led, GPIO.MODE_OUTPUT);
setLED(state.on);

let reportState = function() {
  Shadow.update(0, state);
};

// Blink built-in LED every second
GPIO.set_mode(led, GPIO.MODE_OUTPUT);
Timer.set(1000 /* 1 sec */, Timer.REPEAT, function() {
  if(is_wifi_connect){
    GPIO.write(led,0);
  }else{
    let value = GPIO.toggle(led);
  }
    //print(value ? 'Tick' : 'Tock', 'uptime:', Sys.uptime(), getInfo());

}, null);
// Configure UART at 115200 baud
UART.setConfig(uartNo, {
  baudRate: 115200,
  esp8266: {
    gpio: {
      rx: 03,
      tx: 01,
    },
  },
});


// Set dispatcher callback, it will be called whenver new Rx data or space in
// the Tx buffer becomes available
UART.setDispatcher(uartNo, function(uartNo) {
  let ra = UART.readAvail(uartNo);
  if (ra > 0) {
    // Received new data: print it immediately to the console, and also
    // accumulate in the "rxAcc" variable which will be echoed back to UART later
    let data = UART.read(uartNo);
    print('Received UART data:', data);
    rxAcc += data;
  }
}, null);


// Enable Rx
UART.setRxEnabled(uartNo, true);
Timer.set(4000 /* 1 sec */, Timer.REPEAT, function() {
    if(!is_wifi_connect)
      return;

    let message = 'Temp:';
    counter++;
    if(counter >100)
      counter = 10;
    if(counter < 100){
      message = message+'0'+JSON.stringify(counter);
    }else{
    
      message = message+JSON.stringify(counter);
    }
    message = message + ',Humi:';
    hudi_val ++;
    if(hudi_val >100)
      hudi_val = 10;
    if(hudi_val < 100){
      message = message+'0'+JSON.stringify(hudi_val);
    }else{
    
      message = message+JSON.stringify(hudi_val);
    } 
    let ok = MQTT.pub(outTopic, message, 1);
    print('Published:', ok ? 'yes' : 'no', 'topic:', outTopic, 'message:', message);   
  
  
}, null);
// Publish to MQTT topic on a button press. Button is wired to GPIO pin 0
/*
GPIO.set_button_handler(button, GPIO.PULL_UP, GPIO.INT_EDGE_NEG, 200, function() {
  let message = getInfo();
  let ok = MQTT.pub(topic, message, 1);
  print('Published:', ok, topic, '->', message);
}, null);
*/

MQTT.sub(inTopic, function(conn, topic, msg) {
  print('Topic:', inTopic, 'message:', msg);
}, null);

// Set up Shadow handler to synchronise device state with the shadow state
Shadow.addHandler(function(event, obj) {
  if (event === 'UPDATE_DELTA') {
    print('GOT DELTA:', JSON.stringify(obj));
    for (let key in obj) {  // Iterate over all keys in delta
      if (key === 'on') {   // We know about the 'on' key. Handle it!
        state.on = obj.on;  // Synchronise the state
        setLED(state.on);   // according to the delta
      } else if (key === 'reboot') {
        state.reboot = obj.reboot;      // Reboot button clicked: that
        Timer.set(750, 0, function() {  // incremented 'reboot' counter
          Sys.reboot();                 // Sync and schedule a reboot
        }, null);
      }
    }
    reportState();  // Report our new state, hopefully clearing delta
  }
});

if (btn >= 0) {
  let btnCount = 0;
  let btnPull, btnEdge;
  if (Cfg.get('board.btn1.pull_up') ? GPIO.PULL_UP : GPIO.PULL_DOWN) {
    btnPull = GPIO.PULL_UP;
    btnEdge = GPIO.INT_EDGE_NEG;
  } else {
    btnPull = GPIO.PULL_DOWN;
    btnEdge = GPIO.INT_EDGE_POS;
  }
  GPIO.set_button_handler(btn, btnPull, btnEdge, 20, function() {
    state.btnCount++;
    let message = JSON.stringify(state);
    let sendMQTT = true;
    if (Azure.isConnected()) {
      print('== Sending Azure D2C message:', message);
      Azure.sendD2CMsg('', message);
      sendMQTT = false;
    }
    if (GCP.isConnected()) {
      print('== Sending GCP event:', message);
      GCP.sendEvent(message);
      sendMQTT = false;
    }
    if (Watson.isConnected()) {
      print('== Sending Watson event:', message);
      Watson.sendEventJSON('ev', {d: state});
      sendMQTT = false;
    }
    if (Dash.isConnected()) {
      print('== Click!');
      // TODO: Maybe do something else?
      sendMQTT = false;
    }
    // AWS is handled as plain MQTT since it allows arbitrary topics.
    if (AWS.isConnected() || (MQTT.isConnected() && sendMQTT)) {
      let topic = 'devices/' + Cfg.get('device.id') + '/events';
      print('== Publishing to ' + topic + ':', message);
      MQTT.pub(topic, message, 0 /* QoS */);
    } else if (sendMQTT) {
      print('== Not connected!');
    }
  }, null);
}

Event.on(Event.CLOUD_CONNECTED, function() {
  online = true;
  Shadow.update(0, {ram_total: Sys.total_ram()});
}, null);

Event.on(Event.CLOUD_DISCONNECTED, function() {
  online = false;
}, null);
// Monitor network connectivity.
Event.addGroupHandler(Net.EVENT_GRP, function(ev, evdata, arg) {
  let evs = '???';
  if (ev === Net.STATUS_DISCONNECTED) {
    evs = 'WiFi DISCONNECTED';
    is_wifi_connect = false;
  } else if (ev === Net.STATUS_CONNECTING) {
    evs = 'WiFi CONNECTING';
  } else if (ev === Net.STATUS_CONNECTED) {
    evs = 'WiFi CONNECTED';
    is_wifi_connect = true;
  } else if (ev === Net.STATUS_GOT_IP) {
    evs = 'WiFi GOT_IP';
  }
  print('== Net event:', ev, evs);
}, null);